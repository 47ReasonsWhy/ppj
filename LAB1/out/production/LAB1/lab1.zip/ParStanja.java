public class ParStanja {
    public final Integer lijevo_stanje;
    public final Integer desno_stanje;

    public ParStanja(Integer lijevo_stanje, Integer desno_stanje) {
        this.lijevo_stanje = lijevo_stanje;
        this.desno_stanje = desno_stanje;
    }
}